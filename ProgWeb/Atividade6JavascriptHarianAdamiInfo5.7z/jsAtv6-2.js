const numeros = [1, 2, 3, 4, 5]; 

const quadrado = numeros.map((numeros) => numeros**2)
document.write(quadrado)
