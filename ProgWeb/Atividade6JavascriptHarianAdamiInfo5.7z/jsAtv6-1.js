const times = ['Fluminense', 'Flamengo', 'Vasco', 'Palmeiras', 'São Paulo'];
for (let i = 0; i < times.length; i++) {
    document.writeln(`Minha escolha ${i+1} é ${times[i]}` + '<br>');
}
